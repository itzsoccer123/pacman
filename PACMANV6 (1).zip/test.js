
var x = 100
var y=100 

function setup() {
    createCanvas(600,600)
    angleMode(DEGREES)
    rectMode(CENTER) 
    
}
let deg=1;
function draw() {
    deg += 5
    x = mouseX
    y = mouseY
    background('black')
    fill(255,0,0)
    translate(x,y)
    rotate(deg)
    rect(0,0,100,100)
    rotate(360-deg) 
    translate(-1*x,-1*y)
}