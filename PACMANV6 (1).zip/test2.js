function print(x) {
    console.log(x)
}
let pac
function setup() {
    createCanvas(600,600) 
    angleMode(DEGREES)
    pac = new Pac(300,300,45,5,.98)
    frameRate(pac.fps)
}
let theta = 30
// let score = 0;
function draw() {
  background(0,0,125)
    // theta = mouseX/600*180
// arc(300,300, 600, 600, theta, 0-theta,);
    pac.show()
       pac.move()
    // for (item of pac.points) {
  pac.check()
    if (pac.points.length != 0) {
    print(pac.points[0])
    print(pac.points[0].collision(pac))
        // print(dist(pac.point[0].x,pac.point[0].y))
    }
    textSize(40)
    text(pac.score,300,100)
    fill(255)
    noStroke()
    textAlign(CENTER)
    text('WASD \n keep moving \n eat rocks as u go',300,200)
}
function mousePressed() {
    print(mouseX)
    print(mouseY)
}
function keyPressed() {
    // if (key=='w') {

}
class Pac {
    constructor(x,y,theta,vel,acc) {
        this.rotation = 90
        this.x = x
        this.y = y
        this.w = 20
        this.h = 20
        this.theta=theta 
        this.vel = vel 
        this.maxAngle = 45 
        this.minAngle = 10
        this.points = []
        this.loc_pac = []
        this.framesAlive = 0
        this.fps  = 30
        this.score = 0
    }
    check() {
        
          for (let i=0; i<this.points.length; i++) {
            let item = this.points[i]
            if (item.collision(this)) {
                print(' 1 done')
                print(`${this.score} done`)
                this.score += 1
                this.points.splice(i,1)
                this.check()
            }
        }
    }
    show() {
        this.framesAlive += 1 
        // this.rotation = mouseX/600*360
        arc(this.x,this.y,this.w, this.h, this.theta+this.rotation, 0-this.theta+this.rotation,);
        // if (this.framesAlive%(this.fps/2*4) == 0 ) {
        if (this.framesAlive%(this.fps*2)== 0&& this.loc_pac.length >this.fps) {
            
        this.points.push(new Pebble(this.loc_pac[this.loc_pac.length-10].x,this.loc_pac[this.loc_pac.length-10].y)) 
        }
        this.loc_pac.push(new Point(this.x,this.y))

        
       let item
        for (item of this.points) {
            item.show()
        }
    }
    move() {
     if (keyIsDown(87)) {
        pac.y -= pac.vel
            pac.rotation = 270
    }
    if (keyIsDown(65)) {
        pac.x -= pac.vel
            pac.rotation = 180
        
    }
    // if (key=='s') {
    if (keyIsDown(83)) {
        pac.y += pac.vel
            pac.rotation = 90
        
    }
    // if (key=='d') {
    if (keyIsDown(68)) {
        pac.x+= pac.vel
            pac.rotation = 0
        
    }
        
    }
}
class Point {
    constructor(x,y) {
        this.x = x
        this.y = y 
        
    } 
    show() {
    fill(255)
        ellipse(this.x,this.y,5,5)
        
    }
}
class Pebble {
    constructor(x,y) {
        this.x = x
        this.y = y 
        this.r = 25
    } 
    show() {
    fill(255)
        ellipse(this.x,this.y,this.r*2,this.r*2)
        
    }
    collision(pac) {
        return (dist(pac.x, pac.y, this.x, this.y) <=pac.w+this.r)
    }
}